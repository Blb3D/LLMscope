# LLMscope Documentation Assets

This folder contains screenshots and images referenced in the documentation.

## Required Screenshots

### For README.md
1. **`cognitive-load-spike.png`**
   - Main hero image showing the 9s latency spike
   - Use: Screenshot from your testing showing the full dashboard
   - Recommended size: 1920x1080 or similar
   - File: `/docs/assets/cognitive-load-spike.png`

### For Case Study (CASE_STUDY_Cognitive_Load_Spike_RevA.md)
1. **`baseline-stable.png`**
   - SPC chart showing stable baseline (all points within UCL/LCL)
   - Use: Screenshot from first 30 minutes of testing
   - Recommended: Crop to just the chart area
   - File: `/docs/assets/baseline-stable.png`

2. **`medium-complexity.png`**
   - SPC chart showing occasional violations during medium-complexity tests
   - Use: Screenshot from 30-60 minute mark
   - File: `/docs/assets/medium-complexity.png`

3. **`cognitive-load-spike.png`**
   - Full dashboard view showing the 9s latency spike
   - Use: Same as README hero image
   - File: `/docs/assets/cognitive-load-spike.png`

4. **`violation-modal.png`**
   - Screenshot of the violation details modal
   - Use: Screenshot showing the R1 violation with full context
   - Should show:
     - Rule triggered (R1)
     - Timestamp
     - Latency (1772ms or similar)
     - System telemetry (CPU, GPU, Memory)
     - Context table (±10 points)
   - File: `/docs/assets/violation-modal.png`

## Screenshot Guidelines

### Capturing Screenshots
1. Use LLMscope dashboard at full resolution (1920x1080 recommended)
2. Ensure dark theme is enabled (matches docs aesthetic)
3. Crop out browser chrome (address bar, bookmarks, etc.)
4. Use lossless PNG format (not JPEG)

### Image Optimization
```bash
# Install optipng
sudo apt-get install optipng

# Optimize PNG files
optipng -o7 docs/assets/*.png
```

### Image Sizes
- **README hero image:** Max 2MB, 1920x1080
- **Case study images:** Max 1MB each, 1440x900 or similar
- **Modal screenshots:** Max 500KB, cropped to relevant content

## Current Assets

Based on the uploaded screenshots, you have:

1. **Screenshot_2025-10-24_162854.png** (147KB)
   - Shows: Cognitive load spike conversation + dashboard
   - Use for: `cognitive-load-spike.png`
   - Quality: ✅ Good - shows the full context

2. **3cd395f4-8fa4-4d6e-a086-f5c9070ca930.png** (64KB)
   - Shows: Full LLMscope dashboard with 52 violations
   - Use for: README hero image or case study
   - Quality: ✅ Excellent - clean dashboard view

3. **a0415ea5-69f0-430a-9805-72c4c6360db5.png** (49KB)
   - Shows: Violation details modal
   - Use for: `violation-modal.png`
   - Quality: ✅ Perfect - shows R3 violation with full context

## Recommended Actions

### Step 1: Create Assets Folder
```bash
mkdir -p docs/assets
```

### Step 2: Copy Screenshots
```bash
# Copy your existing screenshots
cp Screenshot_2025-10-24_162854.png docs/assets/cognitive-load-spike-conversation.png
cp 3cd395f4-8fa4-4d6e-a086-f5c9070ca930.png docs/assets/dashboard-full-view.png
cp a0415ea5-69f0-430a-9805-72c4c6360db5.png docs/assets/violation-modal.png
```

### Step 3: Capture Missing Screenshots
You need to capture:
- **Baseline stable chart** - Run LLMscope for 30 min with simple prompts
- **Medium complexity chart** - Test with medium prompts (blog posts)

### Step 4: Create Symlinks (for README)
```bash
# Link case study images to main docs folder
ln -s docs/assets/cognitive-load-spike.png cognitive-load-spike.png
```

## Alternative: Use Existing Screenshots

If you can't capture new screenshots, you can use your existing ones by:

1. **For baseline-stable.png:**
   - Crop the left side of `dashboard-full-view.png` before violations appeared
   - Use any segment where violations = 0

2. **For medium-complexity.png:**
   - Crop a section showing 2-3 violations
   - Alternatively, skip this image and just reference the data in text

3. **For cognitive-load-spike.png:**
   - Use `Screenshot_2025-10-24_162854.png` (already have it!)

4. **For violation-modal.png:**
   - Use `a0415ea5-69f0-430a-9805-72c4c6360db5.png` (already have it!)

## Image Attribution

If you use these screenshots in publications or presentations:

**Credit:**
```
Screenshots from LLMscope v0.2.0 - Open Source SPC Monitoring for LLMs
https://github.com/yourusername/llmscope
```

## License

All screenshots in this folder are licensed under the same MIT license as the LLMscope project.

---

**Need help capturing screenshots?** Open an issue: https://github.com/yourusername/llmscope/issues
