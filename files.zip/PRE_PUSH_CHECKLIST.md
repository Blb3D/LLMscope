# LLMscope Documentation - Pre-Push Checklist

**Before pushing to GitHub, complete this checklist to ensure quality.**

---

## ✅ Mandatory Checks (MUST FIX)

### 1. File Structure
- [ ] `README.md` exists in root
- [ ] `CHANGELOG.md` exists in root
- [ ] `VERSION` exists in root
- [ ] `docs/ROADMAP_v5.md` exists
- [ ] `docs/SCOPE_v5.md` exists
- [ ] `docs/CASE_STUDY_Cognitive_Load_Spike_RevA.md` exists

### 2. Replace Placeholders
Search and replace these in ALL files:

- [ ] `yourusername` → Your GitHub username
- [ ] `your-email@example.com` → Your email
- [ ] `@yourhandle` → Your Twitter/X handle

**Quick command to find placeholders:**
```bash
grep -r "yourusername\|your-email@example.com\|@yourhandle" README.md docs/
```

### 3. Version Number
- [ ] `VERSION` file contains correct version (e.g., `0.2.0`)
- [ ] CHANGELOG.md has entry for this version
- [ ] Version has no extra text (just `0.2.0`, nothing else)

**Verify:**
```bash
cat VERSION
# Should output exactly: 0.2.0
```

### 4. Screenshots
- [ ] Create `docs/assets/` folder
- [ ] Copy your 3 existing screenshots:
  - `Screenshot_2025-10-24_162854.png` → `docs/assets/cognitive-load-spike.png`
  - `3cd395f4-8fa4-4d6e-a086-f5c9070ca930.png` → `docs/assets/dashboard-full-view.png`
  - `a0415ea5-69f0-430a-9805-72c4c6360db5.png` → `docs/assets/violation-modal.png`

**Quick setup:**
```bash
mkdir -p docs/assets
cp Screenshot_2025-10-24_162854.png docs/assets/cognitive-load-spike.png
cp 3cd395f4-8fa4-4d6e-a086-f5c9070ca930.png docs/assets/dashboard-full-view.png
cp a0415ea5-69f0-430a-9805-72c4c6360db5.png docs/assets/violation-modal.png
```

### 5. Links Work
- [ ] Test all internal links (docs/ROADMAP_v5.md, etc.)
- [ ] GitHub username links work after replacing placeholder
- [ ] Email links work after replacing placeholder

**Test a few links manually:**
```bash
# These should exist:
ls docs/ROADMAP_v5.md
ls docs/SCOPE_v5.md
ls LICENSE  # If this fails, create it (see below)
```

---

## ⚠️ Recommended Checks (SHOULD FIX)

### 6. Create LICENSE File
If you don't have one yet:

```bash
# Create MIT License
cat > LICENSE << 'EOF'
MIT License

Copyright (c) 2024 [Your Name]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
EOF
```

### 7. Version Accuracy
- [ ] Is it really v0.2.0? (Check your git tags)
- [ ] Are the features in CHANGELOG accurate?
- [ ] Are email/Slack/wizard really "beta"?

**Double-check:**
```bash
git tag  # See existing versions
```

### 8. Beta Feature Status
Review CHANGELOG.md and README.md:
- [ ] Email alerts marked as "(⚠️ beta - still testing)"?
- [ ] Slack webhooks marked as "(⚠️ beta - still testing)"?
- [ ] Setup wizard marked as "(⚠️ beta - still testing)"?

If any of these are **stable**, remove the beta warning!

### 9. Screenshot Quality
- [ ] Screenshots are PNG format (not JPEG)
- [ ] Images are clear and readable
- [ ] Dark theme matches docs aesthetic
- [ ] No sensitive data visible (API keys, emails)

### 10. Documentation Accuracy
- [ ] Docker setup really takes <15 minutes?
- [ ] Feature descriptions match actual implementation?
- [ ] API examples work with current version?

---

## 🎨 Optional Checks (NICE TO HAVE)

### 11. Create CONTRIBUTING.md
```bash
cat > CONTRIBUTING.md << 'EOF'
# Contributing to LLMscope

Thank you for considering contributing to LLMscope!

## How to Contribute

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Development Setup

See [README.md](README.md) for local development instructions.

## Code of Conduct

Be respectful and inclusive. We welcome contributors of all backgrounds and skill levels.

## Questions?

Open an issue or reach out via email.
EOF
```

### 12. Create .gitignore (if missing)
```bash
cat > .gitignore << 'EOF'
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
ENV/
.venv

# Database
*.db
*.sqlite
*.sqlite3

# Docker
data/
*.log

# OS
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/
*.swp
*.swo

# Node (for frontend)
node_modules/
dist/
*.log

# Env files (keep .env.example, ignore .env)
.env
!.env.example
EOF
```

### 13. Create .env.example
```bash
cat > .env.example << 'EOF'
# LLMscope Configuration Example
# Copy this to .env and update values

# Backend API
LLMSCOPE_API_KEY=dev-123  # CHANGE THIS IN PRODUCTION!
DATABASE_PATH=./data/llmscope.db

# Monitor
USE_OLLAMA=true
OLLAMA_BASE_URL=http://host.docker.internal:11434
OLLAMA_MODEL=llama3
MONITOR_INTERVAL=2

# Optional: Alerts (Phase 2 - Beta)
# SMTP_HOST=smtp.gmail.com
# SMTP_PORT=587
# SMTP_USER=your-email@gmail.com
# SMTP_PASSWORD=your-app-password
# SLACK_WEBHOOK_URL=https://hooks.slack.com/services/YOUR/WEBHOOK/URL
EOF
```

### 14. Add GitHub Issue Templates
Create `.github/ISSUE_TEMPLATE/bug_report.md`:
```bash
mkdir -p .github/ISSUE_TEMPLATE
cat > .github/ISSUE_TEMPLATE/bug_report.md << 'EOF'
---
name: Bug Report
about: Report a bug or issue
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description
A clear description of the bug.

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. See error

## Expected Behavior
What should happen.

## Actual Behavior
What actually happens.

## Environment
- LLMscope Version: [e.g., 0.2.0]
- OS: [e.g., Ubuntu 22.04]
- Docker Version: [e.g., 20.10.21]
- LLM Provider: [e.g., Ollama, OpenAI]

## Screenshots
If applicable, add screenshots.
EOF
```

### 15. Create Pull Request Template
```bash
cat > .github/pull_request_template.md << 'EOF'
## Description
Brief description of changes.

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Performance improvement

## Checklist
- [ ] Code follows project style
- [ ] Tests added/updated
- [ ] Documentation updated
- [ ] No breaking changes (or documented)

## Testing
How was this tested?
EOF
```

---

## 🔍 Automated Validation

Run the validation script to catch common issues:

```bash
# Make it executable
chmod +x validate-docs.sh

# Run validation
./validate-docs.sh
```

This script checks:
- ✅ File structure
- ✅ Placeholders
- ✅ Version consistency
- ✅ Screenshot paths
- ✅ Markdown syntax
- ✅ Git status
- ✅ README quality
- ✅ Sensitive data

---

## 📋 Manual Review Checklist

### README.md
- [ ] Title is clear: "# LLMscope"
- [ ] First paragraph explains what it does
- [ ] "Why LLMscope?" section exists
- [ ] Real-world example table is accurate
- [ ] Features list matches v0.2.0
- [ ] Quick Start takes <15 minutes
- [ ] Screenshots display correctly
- [ ] License badge shows correct license

### CHANGELOG.md
- [ ] Version 0.2.0 entry exists
- [ ] Features listed are accurate
- [ ] Beta features marked as "(⚠️ still testing)"
- [ ] Version dates are correct
- [ ] Breaking changes noted (if any)

### docs/ROADMAP_v5.md
- [ ] Phase 1 marked complete ✅
- [ ] Phase 2 marked complete ✅
- [ ] Phase 3 is primary focus
- [ ] Phase 4 marked as "Long-Term Vision"
- [ ] Success metrics are realistic

### docs/SCOPE_v5.md
- [ ] API endpoints documented
- [ ] Database schemas correct
- [ ] SPC formulas accurate
- [ ] Code examples work

### docs/CASE_STUDY_Cognitive_Load_Spike_RevA.md
- [ ] Data is from real testing
- [ ] Statistics are accurate (9s spike, etc.)
- [ ] Screenshots referenced correctly
- [ ] Reproducibility section honest

---

## 🚀 Final Steps Before Push

1. **Run validation script:**
   ```bash
   ./validate-docs.sh
   ```

2. **Visual review:**
   ```bash
   # Preview README locally
   # Use a markdown viewer or GitHub preview
   ```

3. **Test quick start:**
   ```bash
   # Can you actually set up LLMscope in <15 min?
   docker-compose up -d
   ```

4. **Commit with good message:**
   ```bash
   git add README.md CHANGELOG.md VERSION docs/
   git commit -m "docs: Refactor documentation for v0.2.0 release

   - Updated README with accurate feature list
   - Added beta labels for email/Slack/wizard
   - Cleaned up ROADMAP (focus on Phase 3)
   - Polished SCOPE with complete API specs
   - Verified CASE STUDY with real data
   - Added screenshot placement guide
   
   All features accurately reflect current v0.2.0 status."
   ```

5. **Push to GitHub:**
   ```bash
   git push origin main
   ```

---

## 📊 Post-Push Validation

After pushing, check on GitHub:

- [ ] README renders correctly
- [ ] Screenshots display (not 404)
- [ ] Links work (try clicking a few)
- [ ] Badges show correct status
- [ ] CHANGELOG is readable
- [ ] Case study images load

**View on GitHub:**
```
https://github.com/[yourusername]/llmscope
```

---

## 🎯 Success Criteria

Your documentation is ready when:
- ✅ No placeholders remain
- ✅ Screenshots display correctly
- ✅ Links work
- ✅ Features are accurate
- ✅ Version is correct
- ✅ Validation script passes
- ✅ You'd star this repo if you found it

---

## ❓ Troubleshooting

### Images not displaying on GitHub?
- Check path: `docs/assets/image.png`
- Verify image was committed: `git ls-files docs/assets/`
- Ensure lowercase file extensions (.png not .PNG)

### Links broken?
- Use relative paths: `docs/ROADMAP_v5.md` not `/docs/ROADMAP_v5.md`
- Check file exists: `ls docs/ROADMAP_v5.md`

### Version mismatch?
- Update VERSION file
- Update CHANGELOG.md
- Update package.json (if exists)

### Validation script fails?
- Read error messages carefully
- Fix issues one by one
- Re-run script after each fix

---

## 📬 Need Help?

If you're stuck:
1. Re-read IMPLEMENTATION_GUIDE.md
2. Check validation script output
3. Review this checklist again
4. Open an issue (after pushing initial version)

---

**Remember: Done is better than perfect. Ship it, then iterate!** 🚀
