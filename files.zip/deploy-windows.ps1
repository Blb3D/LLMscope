# LLMscope Documentation Deploy Script for Windows
# Run this in PowerShell from your LLMscope repo root

Write-Host "`n╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║         LLMscope Documentation Deployment (Windows)         ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan

# Configuration - UPDATE THESE!
$GITHUB_USERNAME = "Blb3D"
$YOUR_EMAIL = "bbaker@blb3dprinting.com"
$YOUR_TWITTER = "@Blb3D"  # No Twitter? Will be removed from files
$DOWNLOADS_PATH = "$env:USERPROFILE\Downloads\outputs"  # Where you downloaded files

# ============================================================================
# Step 1: Copy Documentation Files
# ============================================================================
Write-Host "📁 Step 1: Copying documentation files..." -ForegroundColor Yellow

try {
    # Copy root files
    Copy-Item "$DOWNLOADS_PATH\README.md" -Destination "." -Force
    Copy-Item "$DOWNLOADS_PATH\CHANGELOG.md" -Destination "." -Force
    Copy-Item "$DOWNLOADS_PATH\VERSION" -Destination "." -Force
    Copy-Item "$DOWNLOADS_PATH\LICENSE" -Destination "." -Force
    Copy-Item "$DOWNLOADS_PATH\CONTRIBUTING.md" -Destination "." -Force
    Write-Host "   ✓ Copied root files" -ForegroundColor Green
    
    # Create docs folder if doesn't exist
    if (-not (Test-Path "docs")) {
        New-Item -Path "docs" -ItemType Directory | Out-Null
    }
    
    # Copy docs files
    Copy-Item "$DOWNLOADS_PATH\ROADMAP_v5.md" -Destination "docs\" -Force
    Copy-Item "$DOWNLOADS_PATH\SCOPE_v5.md" -Destination "docs\" -Force
    Copy-Item "$DOWNLOADS_PATH\CASE_STUDY_Cognitive_Load_Spike_RevA.md" -Destination "docs\" -Force
    Write-Host "   ✓ Copied docs/ files" -ForegroundColor Green
    
} catch {
    Write-Host "   ✗ Error copying files: $_" -ForegroundColor Red
    Write-Host "`n   Please check that DOWNLOADS_PATH is correct!" -ForegroundColor Yellow
    Write-Host "   Current path: $DOWNLOADS_PATH" -ForegroundColor Yellow
    exit 1
}

# ============================================================================
# Step 2: Create Assets Folder & Add Screenshots
# ============================================================================
Write-Host "`n📸 Step 2: Setting up screenshots..." -ForegroundColor Yellow

try {
    # Create assets folder
    New-Item -Path "docs\assets" -ItemType Directory -Force | Out-Null
    Write-Host "   ✓ Created docs\assets\" -ForegroundColor Green
    
    # Check if screenshots exist in Downloads
    $screenshot1 = Get-ChildItem "$env:USERPROFILE\Downloads" -Filter "*Screenshot_2025-10-24*" | Select-Object -First 1
    $screenshot2 = Get-ChildItem "$env:USERPROFILE\Downloads" -Filter "*3cd395f4*" | Select-Object -First 1
    $screenshot3 = Get-ChildItem "$env:USERPROFILE\Downloads" -Filter "*a0415ea5*" | Select-Object -First 1
    
    if ($screenshot1) {
        Copy-Item $screenshot1.FullName -Destination "docs\assets\cognitive-load-spike.png" -Force
        Write-Host "   ✓ Copied cognitive-load-spike.png" -ForegroundColor Green
    } else {
        Write-Host "   ⚠ Screenshot 1 not found (cognitive-load-spike.png)" -ForegroundColor Yellow
    }
    
    if ($screenshot2) {
        Copy-Item $screenshot2.FullName -Destination "docs\assets\dashboard-full-view.png" -Force
        Write-Host "   ✓ Copied dashboard-full-view.png" -ForegroundColor Green
    } else {
        Write-Host "   ⚠ Screenshot 2 not found (dashboard-full-view.png)" -ForegroundColor Yellow
    }
    
    if ($screenshot3) {
        Copy-Item $screenshot3.FullName -Destination "docs\assets\violation-modal.png" -Force
        Write-Host "   ✓ Copied violation-modal.png" -ForegroundColor Green
    } else {
        Write-Host "   ⚠ Screenshot 3 not found (violation-modal.png)" -ForegroundColor Yellow
    }
    
} catch {
    Write-Host "   ⚠ Warning: Could not copy all screenshots" -ForegroundColor Yellow
    Write-Host "   You can add them manually to docs\assets\" -ForegroundColor Yellow
}

# ============================================================================
# Step 3: Replace Placeholders
# ============================================================================
Write-Host "`n✏️  Step 3: Replacing placeholders..." -ForegroundColor Yellow

$filesToUpdate = @(
    "README.md",
    "CONTRIBUTING.md",
    "docs\ROADMAP_v5.md",
    "docs\SCOPE_v5.md",
    "docs\CASE_STUDY_Cognitive_Load_Spike_RevA.md"
)

foreach ($file in $filesToUpdate) {
    if (Test-Path $file) {
        try {
            $content = Get-Content $file -Raw
            $content = $content -replace 'yourusername', $GITHUB_USERNAME
            $content = $content -replace 'your-email@example.com', $YOUR_EMAIL
            
            # Remove Twitter mentions if no Twitter handle
            if ($YOUR_TWITTER -eq "@Blb3D") {
                # Remove lines with Twitter
                $content = $content -replace '\n.*Twitter:.*@yourhandle.*\n', "`n"
                $content = $content -replace '\n.*\*\*Twitter:\*\*.*@yourhandle.*\n', "`n"
                $content = $content -replace '- \*\*Twitter:\*\*.*@yourhandle.*\n', ''
            } else {
                $content = $content -replace '@yourhandle', $YOUR_TWITTER
            }
            
            Set-Content $file -Value $content -NoNewline
            Write-Host "   ✓ Updated $file" -ForegroundColor Green
        } catch {
            Write-Host "   ✗ Error updating $file" -ForegroundColor Red
        }
    }
}

# Update LICENSE with your name
if (Test-Path "LICENSE") {
    $license = Get-Content "LICENSE" -Raw
    Write-Host "`n   ⚠ Don't forget to replace [Your Name] in LICENSE!" -ForegroundColor Yellow
}

# ============================================================================
# Step 4: Validation
# ============================================================================
Write-Host "`n🔍 Step 4: Validating deployment..." -ForegroundColor Yellow

# Check for remaining placeholders
$remainingPlaceholders = Select-String -Path README.md,docs\*.md -Pattern "yourusername|your-email@example.com" -ErrorAction SilentlyContinue

if ($remainingPlaceholders) {
    Write-Host "   ⚠ Found placeholders still to replace:" -ForegroundColor Yellow
    $remainingPlaceholders | ForEach-Object { Write-Host "      - $($_.Filename): $($_.Line)" }
} else {
    Write-Host "   ✓ No placeholders found" -ForegroundColor Green
}

# Check files exist
$requiredFiles = @(
    "README.md",
    "CHANGELOG.md",
    "VERSION",
    "LICENSE",
    "CONTRIBUTING.md",
    "docs\ROADMAP_v5.md",
    "docs\SCOPE_v5.md"
)

$allFilesExist = $true
foreach ($file in $requiredFiles) {
    if (Test-Path $file) {
        Write-Host "   ✓ $file" -ForegroundColor Green
    } else {
        Write-Host "   ✗ $file (MISSING)" -ForegroundColor Red
        $allFilesExist = $false
    }
}

# Check screenshots
$screenshots = Get-ChildItem "docs\assets\*.png" -ErrorAction SilentlyContinue
if ($screenshots) {
    Write-Host "   ✓ Found $($screenshots.Count) screenshot(s)" -ForegroundColor Green
} else {
    Write-Host "   ⚠ No screenshots in docs\assets\" -ForegroundColor Yellow
}

# ============================================================================
# Step 5: Git Status
# ============================================================================
Write-Host "`n📦 Step 5: Git status..." -ForegroundColor Yellow

try {
    $gitStatus = git status --porcelain
    if ($gitStatus) {
        Write-Host "   ✓ Changes detected, ready to commit" -ForegroundColor Green
        Write-Host "`n   Modified/Added files:" -ForegroundColor Cyan
        git status --short
    } else {
        Write-Host "   ⚠ No changes detected" -ForegroundColor Yellow
    }
} catch {
    Write-Host "   ⚠ Git not available or not in a repo" -ForegroundColor Yellow
}

# ============================================================================
# Summary
# ============================================================================
Write-Host "`n╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║                      DEPLOYMENT SUMMARY                      ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan

if ($allFilesExist -and -not $remainingPlaceholders) {
    Write-Host "✅ ALL CHECKS PASSED!" -ForegroundColor Green
    Write-Host "`nYou're ready to commit and push!" -ForegroundColor Green
    Write-Host "`nNext steps:" -ForegroundColor Cyan
    Write-Host "  1. Review changes: git status" -ForegroundColor White
    Write-Host "  2. Add files: git add ." -ForegroundColor White
    Write-Host "  3. Commit: git commit -m `"docs: Refactor documentation for v0.2.0`"" -ForegroundColor White
    Write-Host "  4. Push: git push origin main" -ForegroundColor White
} else {
    Write-Host "⚠️  Some issues found - please review above" -ForegroundColor Yellow
    Write-Host "`nCommon fixes:" -ForegroundColor Cyan
    Write-Host "  - Update GITHUB_USERNAME, YOUR_EMAIL at top of this script" -ForegroundColor White
    Write-Host "  - Check DOWNLOADS_PATH is correct" -ForegroundColor White
    Write-Host "  - Manually add screenshots to docs\assets\" -ForegroundColor White
    Write-Host "  - Replace [Your Name] in LICENSE" -ForegroundColor White
}

Write-Host "`n🎉 Deployment script complete!`n" -ForegroundColor Cyan
