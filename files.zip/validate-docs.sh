#!/bin/bash
# LLMscope Documentation Pre-Push Validation
# Run this before pushing to GitHub

set -e  # Exit on any error

echo "🔍 LLMscope Documentation Pre-Push Validation"
echo "=============================================="
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

ERRORS=0
WARNINGS=0

# Check if we're in the right directory
if [ ! -f "README.md" ]; then
    echo -e "${RED}❌ ERROR: Not in project root (README.md not found)${NC}"
    echo "Run this script from your project root directory"
    exit 1
fi

echo "✅ Found project root"
echo ""

# ============================================================================
# 1. CHECK FILE STRUCTURE
# ============================================================================
echo "📁 Checking file structure..."

REQUIRED_FILES=(
    "README.md"
    "CHANGELOG.md"
    "VERSION"
    "LICENSE"
    "docs/ROADMAP_v5.md"
    "docs/SCOPE_v5.md"
    "docs/CASE_STUDY_Cognitive_Load_Spike_RevA.md"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo -e "  ${GREEN}✓${NC} $file"
    else
        echo -e "  ${RED}✗${NC} $file ${RED}(MISSING)${NC}"
        if [ "$file" = "LICENSE" ]; then
            echo "    → Create LICENSE file (recommend MIT)"
            WARNINGS=$((WARNINGS + 1))
        else
            ERRORS=$((ERRORS + 1))
        fi
    fi
done
echo ""

# ============================================================================
# 2. CHECK FOR PLACEHOLDERS
# ============================================================================
echo "🔍 Checking for placeholders that need updating..."

PLACEHOLDERS=(
    "yourusername"
    "your-email@example.com"
    "@yourhandle"
    "YOUR_GITHUB_USERNAME"
    "YOUR_EMAIL"
    "YOUR_TWITTER"
)

FILES_TO_CHECK=(
    "README.md"
    "docs/ROADMAP_v5.md"
    "docs/SCOPE_v5.md"
    "docs/CASE_STUDY_Cognitive_Load_Spike_RevA.md"
)

for file in "${FILES_TO_CHECK[@]}"; do
    if [ -f "$file" ]; then
        for placeholder in "${PLACEHOLDERS[@]}"; do
            if grep -q "$placeholder" "$file" 2>/dev/null; then
                echo -e "  ${YELLOW}⚠${NC} Found '$placeholder' in $file"
                WARNINGS=$((WARNINGS + 1))
            fi
        done
    fi
done

if [ $WARNINGS -eq 0 ]; then
    echo -e "  ${GREEN}✓${NC} No placeholders found"
fi
echo ""

# ============================================================================
# 3. CHECK VERSION CONSISTENCY
# ============================================================================
echo "🔢 Checking version consistency..."

if [ -f "VERSION" ]; then
    VERSION=$(cat VERSION | tr -d '[:space:]')
    echo "  Current version: $VERSION"
    
    # Check CHANGELOG mentions this version
    if grep -q "$VERSION" "CHANGELOG.md" 2>/dev/null; then
        echo -e "  ${GREEN}✓${NC} Version found in CHANGELOG.md"
    else
        echo -e "  ${YELLOW}⚠${NC} Version $VERSION not found in CHANGELOG.md"
        WARNINGS=$((WARNINGS + 1))
    fi
else
    echo -e "  ${RED}✗${NC} VERSION file not found"
    ERRORS=$((ERRORS + 1))
fi
echo ""

# ============================================================================
# 4. CHECK SCREENSHOT PATHS
# ============================================================================
echo "📸 Checking screenshot references..."

if [ -d "docs/assets" ]; then
    echo -e "  ${GREEN}✓${NC} docs/assets/ directory exists"
    
    # List files in assets
    ASSET_COUNT=$(find docs/assets -type f 2>/dev/null | wc -l)
    echo "  Found $ASSET_COUNT files in docs/assets/"
    
    # Check for required screenshots
    REQUIRED_SCREENSHOTS=(
        "cognitive-load-spike.png"
        "violation-modal.png"
        "dashboard-full-view.png"
    )
    
    for screenshot in "${REQUIRED_SCREENSHOTS[@]}"; do
        if [ -f "docs/assets/$screenshot" ]; then
            echo -e "  ${GREEN}✓${NC} docs/assets/$screenshot"
        else
            echo -e "  ${YELLOW}⚠${NC} docs/assets/$screenshot (recommended)"
            WARNINGS=$((WARNINGS + 1))
        fi
    done
else
    echo -e "  ${YELLOW}⚠${NC} docs/assets/ directory not found"
    echo "  → Create it and add screenshots"
    WARNINGS=$((WARNINGS + 1))
fi
echo ""

# ============================================================================
# 5. CHECK MARKDOWN SYNTAX
# ============================================================================
echo "📝 Checking markdown syntax..."

# Check for broken links (basic check)
for file in "${FILES_TO_CHECK[@]}"; do
    if [ -f "$file" ]; then
        # Check for malformed links [text](url)
        if grep -E '\]\([^)]*$' "$file" > /dev/null 2>&1; then
            echo -e "  ${RED}✗${NC} Possible broken link in $file"
            ERRORS=$((ERRORS + 1))
        fi
    fi
done

echo -e "  ${GREEN}✓${NC} Basic markdown syntax checks passed"
echo ""

# ============================================================================
# 6. CHECK GIT STATUS
# ============================================================================
echo "📦 Checking git status..."

if git rev-parse --git-dir > /dev/null 2>&1; then
    echo -e "  ${GREEN}✓${NC} Git repository detected"
    
    # Check for uncommitted changes
    if [ -n "$(git status --porcelain)" ]; then
        echo -e "  ${YELLOW}⚠${NC} You have uncommitted changes"
        echo "  → Review with: git status"
        WARNINGS=$((WARNINGS + 1))
    else
        echo -e "  ${GREEN}✓${NC} No uncommitted changes"
    fi
    
    # Check current branch
    BRANCH=$(git branch --show-current)
    echo "  Current branch: $BRANCH"
    
    if [ "$BRANCH" != "main" ] && [ "$BRANCH" != "master" ]; then
        echo -e "  ${YELLOW}⚠${NC} Not on main/master branch"
        WARNINGS=$((WARNINGS + 1))
    fi
else
    echo -e "  ${YELLOW}⚠${NC} Not a git repository"
    echo "  → Initialize with: git init"
    WARNINGS=$((WARNINGS + 1))
fi
echo ""

# ============================================================================
# 7. CHECK README QUALITY
# ============================================================================
echo "📄 Checking README.md quality..."

if [ -f "README.md" ]; then
    # Check length (should be substantial)
    LINES=$(wc -l < README.md)
    if [ "$LINES" -lt 100 ]; then
        echo -e "  ${YELLOW}⚠${NC} README.md is short ($LINES lines)"
        WARNINGS=$((WARNINGS + 1))
    else
        echo -e "  ${GREEN}✓${NC} README.md has $LINES lines"
    fi
    
    # Check for key sections
    SECTIONS=(
        "# LLMscope"
        "## Why LLMscope"
        "## Features"
        "## Quick Start"
        "## Documentation"
        "## License"
    )
    
    for section in "${SECTIONS[@]}"; do
        if grep -q "$section" README.md; then
            echo -e "  ${GREEN}✓${NC} Found: $section"
        else
            echo -e "  ${YELLOW}⚠${NC} Missing: $section"
            WARNINGS=$((WARNINGS + 1))
        fi
    done
fi
echo ""

# ============================================================================
# 8. CHECK FOR SENSITIVE DATA
# ============================================================================
echo "🔒 Checking for sensitive data..."

SENSITIVE_PATTERNS=(
    "dev-123"
    "password"
    "secret"
    "api_key"
    "token"
)

for pattern in "${SENSITIVE_PATTERNS[@]}"; do
    if grep -ri "$pattern" README.md docs/*.md 2>/dev/null | grep -v "LLMSCOPE_API_KEY" | grep -q .; then
        echo -e "  ${YELLOW}⚠${NC} Found '$pattern' in documentation"
        echo "  → Review to ensure no real secrets"
        WARNINGS=$((WARNINGS + 1))
    fi
done

echo -e "  ${GREEN}✓${NC} No obvious sensitive data found"
echo ""

# ============================================================================
# 9. FINAL SUMMARY
# ============================================================================
echo "=============================================="
echo "📊 Validation Summary"
echo "=============================================="
echo ""

if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
    echo -e "${GREEN}✅ ALL CHECKS PASSED!${NC}"
    echo ""
    echo "Your documentation is ready to push to GitHub! 🚀"
    echo ""
    echo "Next steps:"
    echo "  1. git add README.md CHANGELOG.md VERSION docs/"
    echo "  2. git commit -m 'docs: Refactor documentation for v0.2.0'"
    echo "  3. git push origin main"
    exit 0
elif [ $ERRORS -eq 0 ]; then
    echo -e "${YELLOW}⚠️  $WARNINGS WARNING(S) FOUND${NC}"
    echo ""
    echo "Warnings are optional improvements."
    echo "You can still push, but consider fixing them first."
    echo ""
    exit 0
else
    echo -e "${RED}❌ $ERRORS ERROR(S) FOUND${NC}"
    echo -e "${YELLOW}⚠️  $WARNINGS WARNING(S) FOUND${NC}"
    echo ""
    echo "Please fix errors before pushing to GitHub."
    echo ""
    exit 1
fi
