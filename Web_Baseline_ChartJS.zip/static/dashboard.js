// ============================================================
// LLMscope Dashboard – Chart.js baseline (no animation)
// ============================================================

let chartInstance = null;
let initialized = false;

function fmtTime(iso){
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString();
  } catch { return iso; }
}

function setStatus(state, text){
  const dot = document.getElementById("status-dot");
  const label = document.getElementById("status-text");
  if (!dot || !label) return;
  dot.classList.remove("online","offline","warn");
  if (state === "online") dot.classList.add("online");
  else if (state === "warn") dot.classList.add("warn");
  else dot.classList.add("offline");
  label.textContent = text;
}

function updateCards(samples){
  const countEl = document.getElementById("metric-count");
  const avgEl   = document.getElementById("metric-avg");
  const lastEl  = document.getElementById("metric-latest");
  const lastUpd = document.getElementById("last-updated");

  const n = samples.length;
  countEl.textContent = n;

  if (n === 0){
    avgEl.textContent = "--";
    lastEl.textContent = "--";
    lastUpd.textContent = "--:--:--";
    return;
  }

  const last = samples[n-1];
  lastEl.textContent = (last.latency ?? last[1] ?? 0).toFixed(3);
  lastUpd.textContent = fmtTime(last.timestamp ?? last[0] ?? "");

  const tail = samples.slice(-20);
  const vals = tail.map(s => s.latency ?? s[1]).filter(v => typeof v === "number");
  const mean = vals.length ? (vals.reduce((a,b)=>a+b,0)/vals.length) : 0;
  avgEl.textContent = mean.toFixed(3);
}

function ensureChart(){
  if (initialized) return;
  const ph = document.getElementById("chart-placeholder");
  const cvs = document.getElementById("latencyChart");
  if (ph) ph.classList.add("hidden");
  if (cvs) cvs.classList.remove("hidden");

  const ctx = cvs.getContext("2d");
  chartInstance = new Chart(ctx, {
    type: "line",
    data: {
      labels: [],
      datasets: [{
        label: "Latency (s)",
        data: [],
        borderColor: "#D37E3E",
        backgroundColor: "rgba(211,126,62,0.22)",
        borderWidth: 2,
        pointRadius: 2.5,
        pointBackgroundColor: "#F4C98A",
        tension: 0.35
      }]
    },
    options: {
      animation: false,
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: "#F4C98A" } }
      },
      scales: {
        x: {
          ticks: { color: "#F4C98A" },
          grid: { color: "rgba(244,201,138,0.08)" },
          title: { display: true, text: "Time", color: "#F4C98A" }
        },
        y: {
          ticks: { color: "#F4C98A" },
          grid: { color: "rgba(244,201,138,0.08)" },
          title: { display: true, text: "Latency (s)", color: "#F4C98A" }
        }
      }
    }
  });
  initialized = true;
}

async function fetchLive(){
  try {
    const res = await fetch("/api/live");
    const data = await res.json();

    if (data.status !== "ok"){
      setStatus("warn", "API error");
      return;
    }

    const samples = (data.samples ?? []).slice(-50);
    updateCards(samples);

    if (samples.length === 0){
      setStatus("offline", "Waiting…");
      return;
    }

    setStatus("online", "Live");
    ensureChart();

    const labels = samples.map(s => fmtTime(s.timestamp ?? s[0]));
    const values = samples.map(s => (s.latency ?? s[1]));

    chartInstance.data.labels = labels;
    chartInstance.data.datasets[0].data = values;
    chartInstance.update();
  } catch (e){
    console.error("Fetch error:", e);
    setStatus("warn", "Fetch error");
  }
}

window.addEventListener("DOMContentLoaded", () => {
  // First tick immediately
  fetchLive();
  // Then poll every 5 seconds
  setInterval(fetchLive, 5000);
});
