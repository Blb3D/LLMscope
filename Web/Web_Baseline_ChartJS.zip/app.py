from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pathlib import Path
import pandas as pd
import time

# ============================================================
# APP INITIALIZATION
# ============================================================

app = FastAPI(title="LLMscope Dashboard")

# Directories
WEB_DIR = Path(__file__).resolve().parent
TEMPLATES = Jinja2Templates(directory=str(WEB_DIR / "templates"))
STATIC = WEB_DIR / "static"
LOG_FILE = Path("Logs/chatgpt_speed_log.csv")
EXPORTS_DIR = Path("Reports/exports")

# Ensure exports folder exists
EXPORTS_DIR.mkdir(parents=True, exist_ok=True)

# Mount static assets
app.mount("/static", StaticFiles(directory=STATIC), name="static")


# ============================================================
# ROOT DASHBOARD
# ============================================================

@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    """Main dashboard view"""
    return TEMPLATES.TemplateResponse("dashboard.html", {"request": request})


# ============================================================
# LIVE DATA ENDPOINT
# ============================================================

@app.get("/api/live", response_class=JSONResponse)
def api_live():
    """Provide the most recent latency samples for live chart."""
    try:
        if not LOG_FILE.exists():
            return {"status": "ok", "samples": []}

        df = pd.read_csv(LOG_FILE)

        # ✅ Explicitly trim & rename for safety
        df = df.rename(columns=lambda x: x.strip().lower())
        if "timestamp" not in df.columns or "latency" not in df.columns:
            print("[WARN] CSV missing expected columns.")
            return {"status": "ok", "samples": []}

        df = df.tail(50).reset_index(drop=True)

        samples = [
            {"timestamp": str(ts), "latency": float(lat)}
            for ts, lat in zip(df["timestamp"], df["latency"])
        ]

        print(f"[DEBUG] Sending {len(samples)} samples to dashboard")  # helpful for confirming
        return {"status": "ok", "samples": samples}

    except Exception as e:
        print(f"[ERROR] Reading CSV failed: {e}")
        return {"status": "error", "samples": [], "message": str(e)}

# ============================================================
# REPORT ROUTES
# ============================================================

@app.get("/reports", response_class=HTMLResponse)
def reports(request: Request):
    """Display list of generated reports"""
    items = []
    for p in sorted(EXPORTS_DIR.glob("*.pdf"), key=lambda x: x.stat().st_mtime, reverse=True):
        stat = p.stat()
        items.append({
            "name": p.name,
            "created_at": time.strftime("%Y-%m-%d %H:%M", time.localtime(stat.st_mtime)),
            "size_kb": max(1, stat.st_size // 1024),
        })

    return TEMPLATES.TemplateResponse(
        "reports.html",
        {"request": request, "exports": items}
    )


@app.post("/reports/generate")
def reports_generate():
    """Trigger PDF generation from log data"""
    try:
        from Reports.reports_generator import generate_report
        output = generate_report()
        if output:
            print(f"[INFO] Report generated: {output}")
        else:
            print("[WARN] No report generated (missing CSV data).")
    except Exception as e:
        print(f"[ERROR] Report generation failed: {e}")

    return RedirectResponse(url="/reports", status_code=303)


@app.get("/reports/download/{name}")
def reports_download(name: str):
    """Download existing PDF report"""
    file_path = EXPORTS_DIR / name
    if not file_path.exists():
        return {"error": "File not found"}
    return FileResponse(path=file_path, filename=name, media_type="application/pdf")


@app.get("/reports/view/{name}")
def reports_view(name: str):
    """View PDF inline in browser (no download prompt)"""
    file_path = EXPORTS_DIR / name
    if not file_path.exists():
        return {"error": "File not found"}
    headers = {"Content-Disposition": f'inline; filename="{name}"'}
    return FileResponse(path=file_path, media_type="application/pdf", headers=headers)
